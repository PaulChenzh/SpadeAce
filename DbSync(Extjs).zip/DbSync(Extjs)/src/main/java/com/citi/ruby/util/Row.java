package com.citi.ruby.util;

import java.util.ArrayList;
import java.util.List;

public class Row {
	private List<Object> values = new ArrayList<Object>();

	public List<Object> getValues() {
		return values;
	}

	public void setValues(List<Object> values) {
		this.values = values;
	}
}
