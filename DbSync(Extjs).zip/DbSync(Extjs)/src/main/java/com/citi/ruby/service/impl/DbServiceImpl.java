package com.citi.ruby.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citi.ruby.dao.DbDao;
import com.citi.ruby.service.DbService;
import com.citi.ruby.util.Db;
import com.citi.ruby.util.Table;

@Service
public class DbServiceImpl implements DbService {
	
	@Autowired
	DbDao dbDao;

	@Override
	public boolean copyTable(Db originDb, Db goalDb, String tableName) {
		String ddl = dbDao.getTableDDL(originDb, tableName);
		int pos = ddl.indexOf(originDb.getUserName());
		String newDdl = ddl.substring(0, pos) + goalDb.getUserName() + ddl.substring(pos + originDb.getUserName().length());
		dbDao.createTable(goalDb, newDdl);
		Table table = dbDao.selectDataFromTable(originDb, new Table(tableName));
		dbDao.insertDataIntoTable(goalDb, table);
		return true;
	}

}
