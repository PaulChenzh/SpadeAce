package com.citi.ruby.dao;

import org.springframework.stereotype.Repository;

import com.citi.ruby.util.Db;
import com.citi.ruby.util.Table;

@Repository
public interface DbDao {
	public String getTableDDL(Db db, String tableName);
	public void createTable(Db db, String ddl);
	public Table selectDataFromTable(Db db, Table table);
	public void insertDataIntoTable(Db db, Table table);
}	
