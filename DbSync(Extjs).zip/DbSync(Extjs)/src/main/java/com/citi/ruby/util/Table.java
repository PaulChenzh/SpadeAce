package com.citi.ruby.util;

import java.util.ArrayList;
import java.util.List;

public class Table {
	private List<Column> columns = new ArrayList<Column>();
	private List<Row> rowValues = new ArrayList<Row>();
	private String tableName;
	
	public Table() {
	}
	
	public Table(String tableName) {
		this.tableName = tableName;
	}
	public List<Column> getColumns() {
		return columns;
	}
	public void setColumns(List<Column> columns) {
		this.columns = columns;
	}
	public List<Row> getRowValues() {
		return rowValues;
	}
	public void setRowValues(List<Row> rowValues) {
		this.rowValues = rowValues;
	}
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
}

