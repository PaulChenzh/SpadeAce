package com.citi.ruby.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.citi.ruby.dao.DbDao;
import com.citi.ruby.util.Column;
import com.citi.ruby.util.Db;
import com.citi.ruby.util.Row;
import com.citi.ruby.util.Table;

@Repository
public class DbDaoImpl implements DbDao {
	private Logger LOGGER = Logger.getLogger(DbDaoImpl.class);
	
	@Override
	public String getTableDDL(Db db, String tableName) {
		String ddl = null;
		Statement stmt;
		try {
			stmt = getConnection(db).createStatement();
			String sql = "SELECT DBMS_METADATA.GET_DDL('TABLE','" + tableName +"') DDL FROM DUAL";
			ResultSet rs = stmt.executeQuery(sql);
			if (rs.next()){
				ddl = rs.getString("DDL");
			}			
		} catch (SQLException e) {
			LOGGER.error(e);
		}
		return ddl;
	}
	
	@Override
	public void createTable(Db db, String ddl) {
		Statement stmt;
		try {
			stmt = getConnection(db).createStatement();
			stmt.execute(ddl);
		} catch (SQLException e) {
			LOGGER.error(e);
		}
	}

	@Override
	public Table selectDataFromTable(Db db, Table table) {
		Statement stmt;
		try {
			stmt = getConnection(db).createStatement();
			List<Column> columns = findColumns(db.getUserName(), table.getTableName(), stmt);
			table.setColumns(columns);
			ResultSet rs = stmt.executeQuery("Select * from \"" + db.getUserName() + "\".\"" + table.getTableName() + "\"");
			List<Row> rows = table.getRowValues();
			while (rs.next()) {
				Row row = new Row();
				rows.add(row);
				List<Object> rowValues = row.getValues();
				for (int i = 0; i < columns.size(); i ++) {
					Column column = columns.get(i);
					String dataType = column.getDataType();
					if ("NUMBER".equalsIgnoreCase(dataType)) {
						Integer value = rs.getInt(column.getName());
						rowValues.add(value);
					}
				}
			}
			System.out.println("");
		} catch (SQLException e) {
			LOGGER.error(e);
		}
		return table;
	}

	@Override
	public void insertDataIntoTable(Db db, Table table) {
		Connection conn = getConnection(db);
		Statement stmt;
		try {
			conn.setAutoCommit(false);
			stmt = conn.createStatement();
			List<Row> rows = table.getRowValues();
			String sqlHead = "insert into " + "\"" + db.getUserName() + "\".\"" + table.getTableName() + "\" values(";
			String sqlTail = ")";
			for (int i = 0; i < rows.size(); i ++) {
				List<Object> values = rows.get(i).getValues();
				StringBuffer param = new StringBuffer();
				for (int j = 0; j < values.size() - 1; j ++) {
					param.append(values.get(j));
					param.append(',');
				}
				param.append(values.get(values.size() - 1));
				stmt.addBatch(sqlHead + param.toString() + sqlTail);
				if (i % 10000 == 0) {
					stmt.executeBatch();
					conn.commit();
				}
			}
			stmt.executeBatch();
			conn.commit();
		} catch (SQLException e) {
			LOGGER.error(e);
		}
	}
	
	private List<Column> findColumns(String userName, String table, Statement stmt) {
		List<Column> columns = new ArrayList<Column>();
		try {
			ResultSet rs = stmt.executeQuery("select column_name,data_type from all_tab_columns where owner='" + userName + "' and table_name='" + table + "'");
			while (rs.next()) {
				Column column = new Column();
				column.setName(rs.getString("COLUMN_NAME"));
				column.setDataType(rs.getString("DATA_TYPE"));
				columns.add(column);
			}
		} catch (SQLException e) {
			LOGGER.error(e);
		}
		return columns;
	}
	
	private Connection getConnection(Db db) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			LOGGER.error(e);
		}
		String url = "jdbc:oracle:thin:@" + db.getHostname() + ":" + db.getPost() + ":" + db.getSID();
		try {
			return DriverManager.getConnection(url, db.getUserName(), db.getPassword());
		} catch (SQLException e) {
			LOGGER.error(e);
		}
		return null;
	}
}
