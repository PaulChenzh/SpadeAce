package com.citi.ruby.service;

import org.springframework.stereotype.Service;

import com.citi.ruby.util.Db;

@Service
public interface DbService {
	public boolean copyTable(Db originDb, Db goalDb, String tableName);
}	
