package com.citi.ruby.util;

public class Db {
	private String databaseName;
	private String hostname;
	private String post;
	private String SID;
	private String userName;
	private String password;
	
	public Db() {}
	public Db(String databaseName, String hostname, String post, String SID, String userName, String password) {
		this.databaseName = databaseName;
		this.hostname = hostname;
		this.post = post;
		this.SID = SID;
		this.userName = userName;
		this.password = password;
	}
	
	public String getDatabaseName() {
		return databaseName;
	}
	public void setDatabaseName(String databaseName) {
		this.databaseName = databaseName;
	}
	public String getHostname() {
		return hostname;
	}
	public void setHostname(String hostname) {
		this.hostname = hostname;
	}
	public String getPost() {
		return post;
	}
	public void setPost(String post) {
		this.post = post;
	}
	public String getSID() {
		return SID;
	}
	public void setSID(String sID) {
		SID = sID;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
