package com.citi.ruby.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.citi.ruby.service.DbService;
import com.citi.ruby.util.Db;


@Controller
@RequestMapping("/dbSyncController")
public class MainController {
	
	@Autowired
	DbService dbService;
	
//	@RequestMapping("error")
	public String error() {
		System.out.println("mainController: Passing through...");
		System.out.println("error page...");
		return "NotFound";
	}
	
//	@RequestMapping("")
	public String index() {
		System.out.println("mainController: Passing through...");
		System.out.println("main page...");
		return "index";
	}
	
//	@RequestMapping("check")
	public String checkDatabaseExist(String databaseName, String hostname, String post, String SID, String userName, String password) throws Exception {
		return "index";
	}
	
//	@RequestMapping("copyTable")
	public String copyTable(String tableName) throws Exception {
		Db db1 = new Db("aaa", "vm-d399-34cd.nam.nsroot.net", "1522", "cloudapp", "RUBY_SIT", "ruby123");
		Db db2 = new Db("bbb", "vm-574d-989c.nam.nsroot.net", "1522", "cloudapp", "RUBY_SIT5", "ruby123");
		dbService.copyTable(db1, db2, tableName);
		return "index";
	}
	
//	@RequestMapping("copyTable")
//	public String copyTable(String tableName) throws Exception {
//		Db db1 = new Db("aaa", "vm-d399-34cd.nam.nsroot.net", "1522", "cloudapp", "RUBY_SIT", "ruby123");
//		Db db2 = new Db("bbb", "vm-574d-989c.nam.nsroot.net", "1522", "cloudapp", "RUBY_SIT5", "ruby123");
//		dbService.copyTable(db1, db2, tableName);
//		return "index";
//	}
}
