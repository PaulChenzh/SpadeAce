package com.citi.ruby.controller;
import org.junit.Assert;
import org.junit.Test;

public class MainControllerTest {

	@Test
	public void test() {
		MainController controller = new MainController();
		String indexPage = controller.index();
		String errorPage = controller.error();
		Assert.assertEquals(true, indexPage.equals("index"));		
		Assert.assertEquals(true, errorPage.equals("NotFound"));		
	}

}
